var services = angular.module('calcApp.services',[]);	

services.service('quotes',function (){
		
	this.list = [
		'Fridays are always welcome.',
		'Monday are amazing.',
		'Tuesday are very funny.',
		'Wednesday is to enjoy.'
	];	
	
	this.quoteOfDay = function (){
		var idx = Math.floor(Math.random()*this.list.length);
		return this.list[idx];
	}
			
});

services.service('calculator',function ($log){
	
	this.doSum = function(a,b){
		$log.log("Inside calculator.doSum()");
		return parseInt(a) + parseInt(b);
	}			

	this.doDiff = function(a,b){
		$log.log("Inside calculator.doDiff()");
		return parseInt(a) - parseInt(b);
	}			
	
});
