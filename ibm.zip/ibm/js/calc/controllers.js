var controllers = angular.module('calcApp.controllers',['calcApp.services']);	
	
controllers.controller('CalController',function ($scope,calculator,$log,quotes){

	$scope.title = "Math Calculator";
	$scope.valueOne = 10;
	$scope.valueTwo = 10;
	$scope.result = 0;
	$scope.quote = quotes.quoteOfDay();
	
	$scope.calc = function(){
		$log.log("Inside CalController.calc()");
		$scope.result =  calculator.doSum($scope.valueOne,$scope.valueTwo);
		$scope.quote = quotes.quoteOfDay();
	}
	

});
	
			
