var soprtsApp = angular.module('soprtsApp',[]);	

soprtsApp.controller('GameController',function ($scope){
	$scope.title = "Cricket";
	$scope.team = 11;
});
	
soprtsApp.controller('TeamController',function ($scope){
	$scope.names = ['Sachin','Dhoni','Jadeja'];
	$scope.roles = ['Batsman','Keeper','Bowler'];
});

var courseApp = angular.module('courseApp',[]);	

courseApp.controller('CourseController',function ($scope){

	$scope.list = [
		{title:'JSP',duration:16,price:6800.00},
		{title:'Hadoop',duration:40,price:26800.00},
		{title:'Spring',duration:35,price:24500.00},
		{title:'Hibernate',duration:48,price:76800.00}
	];
	
	$scope.months = ['Jan','Feb','Mar'];
		
});

var schoolApp = angular.module('schoolApp',['soprtsApp','courseApp']);	
